const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());

const clientes = [
    {
        id:12,
        nome:"Helena",
        email:"helena@terra.com.br"
    },
    {
        id:56,
        nome:"Wagner",
        email:"wagner@terra.com.br"
    },
    {
        id:48,
        nome:"Thais",
        email:"thais@terra.com.br"
    }
]

app.get("/clientes",(request,response)=>{
    response.send(clientes);
});


app.listen(3000,()=>console.log("Servidor online em http://localhost:3000"))