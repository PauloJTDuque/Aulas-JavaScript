function mensagem(){
    alert("Olá! Bom dia!");
}
function data(){
    alert(new Date().toLocaleDateString());
}

function corFundo(){
    document.body.style.backgroundColor="red";
}
function corTexto(){
    document.getElementsByTagName('button')[0].style.backgroundColor="blue";
    document.getElementsByTagName('button')[1].style.backgroundColor="green";
}


module.exports = {mensagem,data,corFundo,corTexto}

// export {mensagem}
// export {data}
