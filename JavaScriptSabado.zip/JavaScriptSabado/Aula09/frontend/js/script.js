fetch("http://localhost:3000/clientes")
.then((response)=>response.json())
.then((dados)=>{
    const container = document.getElementById("container");

    dados.map((itens)=>{
        container.innerHTML+=`<h2>${itens.nome}</h2>
                            <h4>${itens.email}</h4>`;
    })

}).catch((erro)=>console.error(`Erro -> ${erro}`))