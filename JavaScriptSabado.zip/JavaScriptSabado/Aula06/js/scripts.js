let x=0; 

// function movimenta(){
//     document.getElementById("caixa1").style.marginLeft=`${x}px`;
//     if(x >= window.screen.width-200){
//         x = window.screen.width-200;
//     }
//     else{
//         x+=10;
//     } 
//     console.log('oi')      
// }


var acao = setInterval(movimenta,1000);

function movimenta(){
    document.getElementById("caixa1").style.marginLeft=`${x}px`;
    if(x >= (window.screen.width/2)){
        // para a execução do setInterval
        clearInterval(acao);
    }
    else{
        x+=10;
    } 
    console.log('oi')      
}

document.getElementById("caixa1").onmouseover=()=>{
    document.getElementById("caixa1").style.backgroundColor="blue";
    document.getElementById("caixa1").style.width="300px";
    document.getElementById("caixa1").style.height="300px";

}

document.getElementById("caixa1").onmouseout=()=>{
    document.getElementById("caixa1").style.backgroundColor="darkred";
    document.getElementById("caixa1").style.width="100px";
    document.getElementById("caixa1").style.height="100px";

}
