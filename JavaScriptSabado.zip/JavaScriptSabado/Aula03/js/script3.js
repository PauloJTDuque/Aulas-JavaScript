var salario = prompt("Digite o seu salário");

var desconto = salario>=1000 ? salario*0.07 : salario*0.05;

console.log(desconto);