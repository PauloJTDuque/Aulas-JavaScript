function calculoCPF(){

    var cpf = prompt("Digite o seu CPF");
    /*
    A variável cpf9 irá armazenar os 9 primeiro digitos do cpf para o 
    cálculo. Para capturar os 9 primeiro estamos usando a função 
    substring e passando para ela 2 parâmetros, que são:
    A posição inicial da captura de dados e a quantidade de dados 
    que devem ser capturados.
    */

    //String -> cadeia de caracteres(conjunto do tipo char->caracter)

//           s  a   b   a   d   o            substring(2,5) -> sab
// posição   0  1   2   3   4   5            substring(pos, qtd)
// quanti    1  2   3   4   5   6            sabado[0,]+sabado[1]+sabado[2] -> sab

    var cpf9 = cpf.substring(0,9);
    console.log(cpf9);

    var peso10 = 10;
    var peso11 = 11;

    var resultado = 0;
    var resto = 0;

    for(var i = 0; i < 9; i++){
        resultado += cpf9[i] * peso10;
        peso10--;

    }
    console.log(resultado);
    
    resto = resultado % 11;

    if(resto < 2){
        cpf9+=0;
    }
    else{
        cpf9+=(11-resto);
    }

    resultado = 0;

    for(var i = 0; i < 10; i++){
        resultado += cpf9[i] * peso11;
        peso11--;

    }
    console.log(resultado);
    
    resto = resultado % 11;

    if(resto < 2){
        cpf9+=0;
    }
    else{
        cpf9+=(11-resto);
    }
    console.log(cpf9);

    if(cpf != cpf9){
        alert("CPF Inválido");
    }
    else{
        alert("CPF Válido");
    }

}